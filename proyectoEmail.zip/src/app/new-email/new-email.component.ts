import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-new-email',
  templateUrl: './new-email.component.html',
  styleUrls: ['./new-email.component.css']
})
export class NewEmailComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
