import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-actions-bar',
  templateUrl: './actions-bar.component.html',
  styleUrls: ['./actions-bar.component.css']
})
export class ActionsBarComponent implements OnInit {

  constructor() { }
  
  ngOnInit(): void {
  }
  
  visible:boolean=false;
  toggleEmail(){
    this.visible = !this.visible;
  }

}
